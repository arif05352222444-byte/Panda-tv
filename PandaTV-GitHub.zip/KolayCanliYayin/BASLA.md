# Panda TV — kurulum

Bu paket Android TV uygulamasının 0.2.0 sürümünün kaynak kodudur. APK'yı GitHub Actions üretir. Telefon sayfası ve bağlantı hizmeti ayrıca yayımlanmıştır; Render hesabı veya sunucu kurulumu gerekmez.

## Mevcut GitHub depon için

1. Depodaki eski `PandaTV-GitHub.zip` dosyasını bu yeni ZIP ile değiştir. Adı tam olarak `PandaTV-GitHub.zip` olsun.
2. Depodaki `.github/workflows/build-apk.yml` dosyasının içeriğini verilen yeni `build-apk.yml` ile değiştir. Eski Node.js test adımları kullanılmayacak.
3. **Actions → Build APK** çalışmasını aç. İki dosya da yüklendikten sonraki çalışmayı kullan; gerekirse **Run workflow** seç.
4. Yeşil tamamlandığında **Artifacts → PandaTV-APK** paketini indir. İçindeki `app-debug.apk` dosyasını TV'ye kur.

ZIP'i kendin açıp proje dosyalarını repo köküne yüklemek de desteklenir. Bu durumda ZIP içindeki `.github/workflows/build-apk.yml` dosyası da repo kökünde aynı yolda bulunmalı.

## TV ve iPhone

1. İkisini aynı normal Wi-Fi ağına bağla. İnternet erişimi de açık olsun.
2. Yeni Panda TV uygulamasını TV'de aç. Adres girmeden QR ekranına geçer.
3. iPhone kamerasıyla QR kodunu okut. Safari'de **Kamerayı aç ve bağlan** seç; kamera ve mikrofon izinlerini ver.
4. TV kumandasında **Yayını kabul et** seç.
5. Yayın sırasında Safari açık kalsın; telefonu kilitleme. Ön/arka kamera ve mikrofon düğmeleri telefon sayfasındadır.

TV'de **Tam ekran** çerçeveyi gizler; Panda TV logosu sol üstte kalır. **Yeni yayın** mevcut bağlantıyı kapatıp yeni QR oluşturur. Menü tuşu isteğe bağlı ayarları açar.

## Elindeki eski APK ile hemen denemek

Eski APK'nın adres isteyen ekranına aşağıdaki adresi bir kez yazıp kaydet:

https://panda-tv-live.arfvesen.chatgpt.site

Sonuna `/tv` ekleme. Yeni APK bu adresi hazır içerir.

## Kurulumda "uygulama yüklenmedi" çıkarsa

GitHub'ın debug imzası önceki APK'nın imzasından farklı olabilir. Bu durumda eski Panda TV beta uygulamasını kaldırıp yenisini kur. Yalnızca bu uygulamanın ayarı silinir.

## İlk gerçek cihaz testi

Kamera görüntüsü, mikrofon sesi, kamera değiştirme ve kumanda onayını birlikte kontrol et. Sonra en az 5 dakika yayın yap. Takılma olursa TV modeli, Android sürümü, iPhone modeli ve ekrandaki mesaj gerekli. Aynı odada ses yankısı olursa TV sesini azalt.

720p/30 fps hedeflenir. Bağlantı zayıfladığında 480p/24 veya 360p/20 hedeflerine düşebilir. TV/modem uyumluluğu ve gerçek akıcılık fiziksel cihaz testinde doğrulanmalıdır.
