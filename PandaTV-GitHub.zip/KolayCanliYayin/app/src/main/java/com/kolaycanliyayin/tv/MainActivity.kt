package com.kolaycanliyayin.tv

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.ImageView
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.ByteArrayOutputStream
import java.net.URI

class MainActivity : Activity() {
    private var browser: WebView? = null
    private var serverUrl = ""
    private var paused = false
    private var loading: View? = null
    private val prefs by lazy { getSharedPreferences("live_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        serverUrl = validUrl(prefs.getString("server", "").orEmpty()) ?: BuildConfig.DEFAULT_SERVER_URL
        if (validUrl(serverUrl) == null) showSettings() else openTv()
    }
    private fun validUrl(value: String): String? = try {
        val uri = URI(value.trim())
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null || uri.query != null || uri.fragment != null || (uri.path.isNotEmpty() && uri.path != "/")) null
        else "https://${uri.rawAuthority}"
    } catch (_: Exception) { null }

    private fun destroyBrowser() {
        browser?.apply { evaluateJavascript("window.stopLive && window.stopLive()", null); stopLoading(); loadUrl("about:blank"); removeJavascriptInterface("TVBridge"); destroy() }
        browser = null
        loading = null
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(40), dp(24), dp(40), dp(24))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(48, 42, 31), Color.rgb(18, 21, 17)))
    }
    private fun label(value: String, size: Float): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(255, 244, 219)); setPadding(0, dp(6), 0, dp(10))
    }
    private fun logo(): ImageView = ImageView(this).apply { setImageResource(R.drawable.panda_logo); contentDescription = "Panda TV"; scaleType = ImageView.ScaleType.FIT_START }
    private fun showSettings() {
        destroyBrowser()
        val layout = panel()
        layout.addView(logo(), LinearLayout.LayoutParams(dp(130), dp(66)))
        layout.addView(label("Yayın ayarları", 26f).apply { typeface = Typeface.create("serif", Typeface.BOLD) })
        layout.addView(label("Panda TV bağlantısı hazır. Bu adresi normal kullanımda değiştirmen gerekmez.", 16f))
        val input = EditText(this).apply { setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setText(serverUrl); setTextColor(Color.WHITE); textSize = 16f }
        layout.addView(input)
        val error = label("", 15f)
        layout.addView(Button(this).apply {
            text = "Kaydet ve TV’yi aç"
            setOnClickListener {
                val clean = validUrl(input.text.toString())
                if (clean == null) error.text = "Yalnızca geçerli HTTPS ana adresini yaz. Sonuna /tv ekleme."
                else { serverUrl = clean; prefs.edit().putString("server", clean).apply(); openTv() }
            }
        })
        layout.addView(error)
        layout.addView(Button(this).apply {
            text = "Hazır Panda TV bağlantısına dön"
            setOnClickListener { prefs.edit().remove("server").apply(); serverUrl = BuildConfig.DEFAULT_SERVER_URL; openTv() }
        })
        layout.addView(label("Telefon ve TV aynı Wi-Fi’da olmalı. İnternet erişimi ve güncel Android System WebView gerekir.", 14f))
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(layout) })
    }
    @SuppressLint("SetJavaScriptEnabled")
    private fun openTv() {
        destroyBrowser()
        val view = WebView(this)
        browser = view
        view.setBackgroundColor(Color.BLACK)
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(false)
        }
        view.addJavascriptInterface(Bridge(), "TVBridge")
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(web: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val allowed = URI(serverUrl)
                return url.scheme != "https" || url.host != allowed.host || url.port != allowed.port
            }
            override fun onReceivedError(web: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    loading?.visibility = View.GONE
                    AlertDialog.Builder(this@MainActivity).setTitle("Sunucuya bağlanılamadı")
                        .setMessage("TV’nin internet bağlantısını kontrol edip tekrar dene.\n${error.description}")
                        .setPositiveButton("Tekrar dene") { _, _ -> openTv() }
                        .setNegativeButton("Ayarlar") { _, _ -> showSettings() }.show()
                }
            }
            override fun onPageFinished(web: WebView, url: String) {
                if (web === browser) loading?.visibility = View.GONE
            }
        }
        val root = FrameLayout(this)
        root.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val intro = panel().apply {
            gravity = Gravity.CENTER
            addView(logo(), LinearLayout.LayoutParams(dp(190), dp(100)))
            addView(label("Kanalın hazırlanıyor…", 26f).apply { typeface = Typeface.create("serif", Typeface.BOLD) })
            addView(label("Birazdan QR kodunu telefonunla okutabilirsin.", 16f))
            addView(ProgressBar(this@MainActivity), LinearLayout.LayoutParams(dp(36), dp(36)))
        }
        loading = intro
        root.addView(intro, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root); view.requestFocus(); view.loadUrl("$serverUrl/tv")
    }
    inner class Bridge {
        @JavascriptInterface fun qr(text: String): String {
            if (text.length > 2048 || !text.startsWith("$serverUrl/#")) return ""
            return try {
                val matrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 512, 512, mapOf(EncodeHintType.MARGIN to 3))
                val pixels = IntArray(512 * 512) { i -> if (matrix[i % 512, i / 512]) Color.BLACK else Color.WHITE }
                val bitmap = Bitmap.createBitmap(pixels, 512, 512, Bitmap.Config.ARGB_8888)
                val bytes = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes); bitmap.recycle()
                "data:image/png;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
            } catch (_: Exception) { "" }
        }
        @JavascriptInterface fun settings() { runOnUiThread { showSettings() } }
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) { showSettings(); return true }
        return super.onKeyDown(keyCode, event)
    }
    @Deprecated("TV remote back")
    override fun onBackPressed() {
        AlertDialog.Builder(this).setTitle("Yayını kapatıp çık?")
            .setPositiveButton("Çık") { _, _ -> finish() }.setNegativeButton("Devam et", null).show()
    }
    override fun onResume() { super.onResume(); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); browser?.onResume(); if (paused) browser?.reload(); paused = false }
    override fun onPause() { browser?.evaluateJavascript("window.stopLive && window.stopLive()", null); browser?.onPause(); paused = true; window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); super.onPause() }
    override fun onDestroy() { destroyBrowser(); super.onDestroy() }
}
