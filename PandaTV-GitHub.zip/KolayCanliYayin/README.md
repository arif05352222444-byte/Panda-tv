# Panda TV 0.2.0 beta

iPhone kamerasını ve mikrofon sesini aynı Wi-Fi ağındaki Android TV'ye gönderen uygulama. TV ve telefon arayüzü retro tasarımlıdır; canlı görüntüye filtre, çizgi veya eski film efekti uygulanmaz. Panda TV logosu sol üstte sabittir.

Kurulum: **BASLA.md**. GitHub Actions hem ZIP yükleme hem açılmış proje düzenini destekler.

## Hazır bağlantı hizmeti

https://panda-tv-live.arfvesen.chatgpt.site

HTTPS telefon sayfası, TV sayfası ve eşleştirme API'si ayrı olarak yayımlanır. APK bu hizmeti açar. Bu ZIP, Android projesini içerir; eski Node/Render prototipini içermez ve yeniden sunucu kurmayı gerektirmez. Yayımlanan web projesinin kaynak sürümü ayrı Site projesinde saklanır.

İnternet sayfaları ve bağlantı mesajları için gerekir. Kamera/ses WebRTC ile doğrudan yerel ağ üzerinden taşınır; kayıt yapılmaz. STUN/TURN aktarım hizmeti bulunmaz, uzaktan internet yayını bu sürümde desteklenmez. Misafir ağı, cihaz yalıtımı veya mDNS/yerel ağ kısıtlaması bağlantıyı engelleyebilir.

## Yayın davranışı

- TV'de 5 dakika geçerli, tek telefonluk QR ve açık yayın onayı.
- Başlangıç hedefi 720p/30 fps; otomatik hız kontrolü, kötü bağlantıda daha düşük çözünürlük/kare hızı hedefi.
- TV'de yaklaşık 6,5 saniye yeni görüntü alınamazsa bağlantı durumu gösterilir ve yeniden bağlantı istenir.
- En fazla dört yeniden bağlantı denemesi; başarısız olursa yeni QR ile başlama mesajı.
- Telefon Safari'de arka plana geçince yayın kapanır. Telefonu kilitlemeden sayfayı açık tut.
- TV uygulaması arka plana geçince yayın kapanır; yeniden açıldığında yeni oturum oluşur.
- Ekran uyanık tutma destekleniyorsa kullanılır; iOS düşük güç veya sistem kısıtlamaları bu isteği reddedebilir.
- Yayın oturumu üst sınırı 4 saattir. Ardından yeni QR gerekir.
- Ön/arka kamera değiştirme, mikrofon aç/kapat, yayını bitirme; TV kumandasında yön tuşları ve OK.

## Android projesi

Kotlin Activity + donanım hızlandırmalı HTTPS WebView; native libwebrtc değildir. Android TV 8.0+ (API 26), güncel Android System WebView ve WebRTC desteği gerekir. Telefon tarafı güncel iPhone Safari'dir.

- JDK 17; Gradle 8.11.1; Android Gradle Plugin 8.9.2; Kotlin 2.1.10.
- compileSdk/targetSdk 35; ZXing 3.5.3.
- Gradle wrapper yerine Actions `setup-gradle` ile sabit Gradle sürümünü kurar.
- Derleme ve denetim: `gradle --no-daemon :app:assembleDebug :app:lintDebug`.
- Debug paket: `com.kolaycanliyayin.tv.debug`; sürüm kodu `100 + BUILD_NUMBER`.
- Varsayılan HTTPS adresi kaynakta hazırdır. `APP_URL` isteğe bağlı derleme ortam değişkeniyle değiştirilebilir; normal kullanımda gerekmez.
- Android kamera/mikrofon izni istemez; TV yalnız alıcıdır. Telefon izinleri Safari'de verilir.

Bu paket test amaçlı debug APK üretir. Kalıcı mağaza/dağıtım sürümü için ayrı, güvenli saklanan üretim imza anahtarı gerekir. Projede isteğe bağlı release imzalama değişkenleri korunmuştur; imza anahtarı ZIP'e dahil değildir.

## Doğrulama sınırı

Web projesi derlendi; TypeScript denetimi ve sunucu/arayüz otomatik kontrolleri geçti. Android XML kaynakları kontrol edildi. Bu çalışma ortamında yeni Android APK derlenemedi; Actions sonucu ve gerçek iPhone/TV testi ayrı doğrulamalardır. Önceki 0.1 APK'nın TV'de açılması, 0.2 sürümünün canlı yayın akıcılığını kanıtlamaz. Donmasız yayın garantisi verilmez.
